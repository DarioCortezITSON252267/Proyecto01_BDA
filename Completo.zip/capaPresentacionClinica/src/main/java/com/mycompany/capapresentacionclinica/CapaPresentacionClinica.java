/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.capapresentacionclinica;

import GUI.PantallaInicio;

/**
 *
 * @author chris
 */
public class CapaPresentacionClinica {

    public static void main(String[] args) {
        PantallaInicio inicioSesion = new PantallaInicio();
        inicioSesion.setVisible(true);
    }
}
